package com.jcraft.jorbis;

class Drft {
	int n;
	float[] trigcache;
	int[] splitcache;
	static int[] ntryh = new int[]{4, 2, 3, 5};
	static float tpi = 6.2831855F;
	static float hsqt2 = 0.70710677F;
	static float taui = 0.8660254F;
	static float taur = -0.5F;
	static float sqrt2 = 1.4142135F;

	void backward(float[] f1) {
		if(this.n != 1) {
			drftb1(this.n, f1, this.trigcache, this.trigcache, this.n, this.splitcache);
		}
	}

	void init(int i1) {
		this.n = i1;
		this.trigcache = new float[i1 * 3];
		this.splitcache = new int[32];
		fdrffti(i1, this.trigcache, this.splitcache);
	}

	void clear() {
		if(this.trigcache != null) {
			this.trigcache = null;
		}

		if(this.splitcache != null) {
			this.splitcache = null;
		}

	}

	static void drfti1(int i0, float[] f1, int i2, int[] i3) {
		int i4 = 0;
		int i9 = -1;
		int i7 = i0;
		int i10 = 0;
		byte b5 = 101;

		while(true) {
			while(true) {
				int i8;
				switch(b5) {
				case 101:
					++i9;
					if(i9 < 4) {
						i4 = ntryh[i9];
					} else {
						i4 += 2;
					}
				case 104:
					int i19 = i7 / i4;
					if(i7 - i4 * i19 != 0) {
						b5 = 101;
						break;
					} else {
						++i10;
						i3[i10 + 1] = i4;
						i7 = i19;
						if(i4 != 2) {
							b5 = 107;
							break;
						} else if(i10 == 1) {
							b5 = 107;
							break;
						} else {
							for(i8 = 1; i8 < i10; ++i8) {
								i19 = i10 - i8 + 1;
								i3[i19 + 1] = i3[i19];
							}

							i3[2] = 2;
						}
					}
				case 107:
					if(i7 == 1) {
						i3[0] = i0;
						i3[1] = i10;
						float f21 = tpi / (float)i0;
						int i15 = 0;
						int i18 = i10 - 1;
						int i11 = 1;
						if(i18 == 0) {
							return;
						}

						for(i10 = 0; i10 < i18; ++i10) {
							i4 = i3[i10 + 2];
							int i13 = 0;
							int i12 = i11 * i4;
							int i16 = i0 / i12;
							int i17 = i4 - 1;

							for(i9 = 0; i9 < i17; ++i9) {
								i13 += i11;
								i8 = i15;
								float f6 = (float)i13 * f21;
								float f22 = 0.0F;

								for(int i14 = 2; i14 < i16; i14 += 2) {
									float f20 = ++f22 * f6;
									f1[i2 + i8++] = (float)Math.cos((double)f20);
									f1[i2 + i8++] = (float)Math.sin((double)f20);
								}

								i15 += i16;
							}

							i11 = i12;
						}

						return;
					}

					b5 = 104;
				}
			}
		}
	}

	static void fdrffti(int i0, float[] f1, int[] i2) {
		if(i0 != 1) {
			drfti1(i0, f1, i0, i2);
		}
	}

	static void dradf2(int i0, int i1, float[] f2, float[] f3, float[] f4, int i5) {
		int i11 = 0;
		int i12;
		int i10 = i12 = i1 * i0;
		int i13 = i0 << 1;

		int i7;
		for(i7 = 0; i7 < i1; ++i7) {
			f3[i11 << 1] = f2[i11] + f2[i12];
			f3[(i11 << 1) + i13 - 1] = f2[i11] - f2[i12];
			i11 += i0;
			i12 += i0;
		}

		if(i0 >= 2) {
			if(i0 != 2) {
				i11 = 0;
				i12 = i10;

				for(i7 = 0; i7 < i1; ++i7) {
					i13 = i12;
					int i14 = (i11 << 1) + (i0 << 1);
					int i15 = i11;
					int i16 = i11 + i11;

					for(int i6 = 2; i6 < i0; i6 += 2) {
						i13 += 2;
						i14 -= 2;
						i15 += 2;
						i16 += 2;
						float f9 = f4[i5 + i6 - 2] * f2[i13 - 1] + f4[i5 + i6 - 1] * f2[i13];
						float f8 = f4[i5 + i6 - 2] * f2[i13] - f4[i5 + i6 - 1] * f2[i13 - 1];
						f3[i16] = f2[i15] + f8;
						f3[i14] = f8 - f2[i15];
						f3[i16 - 1] = f2[i15 - 1] + f9;
						f3[i14 - 1] = f2[i15 - 1] - f9;
					}

					i11 += i0;
					i12 += i0;
				}

				if(i0 % 2 == 1) {
					return;
				}
			}

			i11 = i0;
			i13 = i12 = i0 - 1;
			i12 += i10;

			for(i7 = 0; i7 < i1; ++i7) {
				f3[i11] = -f2[i12];
				f3[i11 - 1] = f2[i13];
				i11 += i0 << 1;
				i12 += i0;
				i13 += i0;
			}

		}
	}

	static void dradf4(int i0, int i1, float[] f2, float[] f3, float[] f4, int i5, float[] f6, int i7, float[] f8, int i9) {
		int i12;
		int i13 = i12 = i1 * i0;
		int i16 = i12 << 1;
		int i14 = i12 + i16;
		int i15 = 0;

		int i11;
		int i17;
		float f20;
		float f24;
		for(i11 = 0; i11 < i1; ++i11) {
			f24 = f2[i13] + f2[i14];
			f20 = f2[i15] + f2[i16];
			f3[i17 = i15 << 2] = f24 + f20;
			f3[(i0 << 2) + i17 - 1] = f20 - f24;
			f3[(i17 += i0 << 1) - 1] = f2[i15] - f2[i16];
			f3[i17] = f2[i14] - f2[i13];
			i13 += i0;
			i14 += i0;
			i15 += i0;
			i16 += i0;
		}

		if(i0 >= 2) {
			int i18;
			float f21;
			if(i0 != 2) {
				i13 = 0;

				for(i11 = 0; i11 < i1; ++i11) {
					i14 = i13;
					i16 = i13 << 2;
					i17 = (i18 = i0 << 1) + i16;

					for(int i10 = 2; i10 < i0; i10 += 2) {
						i14 += 2;
						i16 += 2;
						i17 -= 2;
						i15 = i14 + i12;
						f21 = f4[i5 + i10 - 2] * f2[i15 - 1] + f4[i5 + i10 - 1] * f2[i15];
						float f19 = f4[i5 + i10 - 2] * f2[i15] - f4[i5 + i10 - 1] * f2[i15 - 1];
						i15 += i12;
						float f22 = f6[i7 + i10 - 2] * f2[i15 - 1] + f6[i7 + i10 - 1] * f2[i15];
						f20 = f6[i7 + i10 - 2] * f2[i15] - f6[i7 + i10 - 1] * f2[i15 - 1];
						i15 += i12;
						float f23 = f8[i9 + i10 - 2] * f2[i15 - 1] + f8[i9 + i10 - 1] * f2[i15];
						float f26 = f8[i9 + i10 - 2] * f2[i15] - f8[i9 + i10 - 1] * f2[i15 - 1];
						f24 = f21 + f23;
						float f25 = f23 - f21;
						f21 = f19 + f26;
						f23 = f19 - f26;
						f26 = f2[i14] + f20;
						f19 = f2[i14] - f20;
						f20 = f2[i14 - 1] + f22;
						f22 = f2[i14 - 1] - f22;
						f3[i16 - 1] = f24 + f20;
						f3[i16] = f21 + f26;
						f3[i17 - 1] = f22 - f23;
						f3[i17] = f25 - f19;
						f3[i16 + i18 - 1] = f23 + f22;
						f3[i16 + i18] = f25 + f19;
						f3[i17 + i18 - 1] = f20 - f24;
						f3[i17 + i18] = f21 - f26;
					}

					i13 += i0;
				}

				if((i0 & 1) != 0) {
					return;
				}
			}

			i14 = (i13 = i12 + i0 - 1) + (i12 << 1);
			i15 = i0 << 2;
			i16 = i0;
			i17 = i0 << 1;
			i18 = i0;

			for(i11 = 0; i11 < i1; ++i11) {
				f21 = -hsqt2 * (f2[i13] + f2[i14]);
				f24 = hsqt2 * (f2[i13] - f2[i14]);
				f3[i16 - 1] = f24 + f2[i18 - 1];
				f3[i16 + i17 - 1] = f2[i18 - 1] - f24;
				f3[i16] = f21 - f2[i13 + i12];
				f3[i16 + i17] = f21 + f2[i13 + i12];
				i13 += i0;
				i14 += i0;
				i16 += i15;
				i18 += i0;
			}

		}
	}

	static void dradfg(int i0, int i1, int i2, int i3, float[] f4, float[] f5, float[] f6, float[] f7, float[] f8, float[] f9, int i10) {
		float f11;
		Math.cos((double)(f11 = tpi / (float)i1));
		Math.sin((double)f11);
	}

	static void drftf1(int i0, float[] f1, float[] f2, float[] f3, int[] i4) {
		int i9 = i4[1];
		int i8 = 1;
		int i7 = i0;
		int i11 = i0;

		for(int i5 = 0; i5 < i9; ++i5) {
			int i6 = i9 - i5;
			int i10 = i4[i6 + 1];
			i6 = i7 / i10;
			int i12 = (i7 = i0 / i7) * i6;
			i11 -= (i10 - 1) * i7;
			i8 = 1 - i8;
			byte b13 = 100;

			label62:
			while(true) {
				switch(b13) {
				case 100:
					if(i10 != 4) {
						b13 = 102;
					} else {
						int i16;
						int i14 = (i16 = i11 + i7) + i7;
						if(i8 != 0) {
							dradf4(i7, i6, f2, f1, f3, i11 - 1, f3, i16 - 1, f3, i14 - 1);
						} else {
							dradf4(i7, i6, f1, f2, f3, i11 - 1, f3, i16 - 1, f3, i14 - 1);
						}

						b13 = 110;
					}
				case 101:
				case 105:
				case 106:
				case 107:
				case 108:
				default:
					break;
				case 102:
					if(i10 != 2) {
						b13 = 104;
					} else if(i8 != 0) {
						b13 = 103;
					} else {
						dradf2(i7, i6, f1, f2, f3, i11 - 1);
						b13 = 110;
					}
					break;
				case 103:
					dradf2(i7, i6, f2, f1, f3, i11 - 1);
				case 104:
					if(i7 == 1) {
						i8 = 1 - i8;
					}

					if(i8 != 0) {
						b13 = 109;
					} else {
						dradfg(i7, i10, i6, i12, f1, f1, f1, f2, f2, f3, i11 - 1);
						i8 = 1;
						b13 = 110;
					}
					break;
				case 109:
					dradfg(i7, i10, i6, i12, f2, f2, f2, f1, f1, f3, i11 - 1);
					i8 = 0;
				case 110:
					break label62;
				}
			}

			i7 = i6;
		}

		if(i8 != 1) {
			for(int i15 = 0; i15 < i0; ++i15) {
				f1[i15] = f2[i15];
			}

		}
	}

	static void dradb2(int i0, int i1, float[] f2, float[] f3, float[] f4, int i5) {
		int i8 = i1 * i0;
		int i9 = 0;
		int i6 = 0;
		int i10 = (i0 << 1) - 1;

		int i7;
		for(i7 = 0; i7 < i1; ++i7) {
			f3[i9] = f2[i6] + f2[i10 + i6];
			f3[i9 + i8] = f2[i6] - f2[i10 + i6];
			i6 = (i9 += i0) << 1;
		}

		if(i0 >= 2) {
			if(i0 != 2) {
				i9 = 0;
				i6 = 0;

				for(i7 = 0; i7 < i1; ++i7) {
					i10 = i9;
					int i11 = i6;
					int i12 = i6 + (i0 << 1);
					int i13 = i8 + i9;

					for(i6 = 2; i6 < i0; i6 += 2) {
						i10 += 2;
						i11 += 2;
						i12 -= 2;
						i13 += 2;
						f3[i10 - 1] = f2[i11 - 1] + f2[i12 - 1];
						float f15 = f2[i11 - 1] - f2[i12 - 1];
						f3[i10] = f2[i11] - f2[i12];
						float f14 = f2[i11] + f2[i12];
						f3[i13 - 1] = f4[i5 + i6 - 2] * f15 - f4[i5 + i6 - 1] * f14;
						f3[i13] = f4[i5 + i6 - 2] * f14 + f4[i5 + i6 - 1] * f15;
					}

					i6 = (i9 += i0) << 1;
				}

				if(i0 % 2 == 1) {
					return;
				}
			}

			i6 = i9 = i0 - 1;

			for(i7 = 0; i7 < i1; ++i7) {
				f3[i9] = f2[i6] + f2[i6];
				f3[i9 + i8] = -(f2[i6 + 1] + f2[i6 + 1]);
				i9 += i0;
				i6 += i0 << 1;
			}

		}
	}

	static void dradb3(int i0, int i1, float[] f2, float[] f3, float[] f4, int i5, float[] f6, int i7) {
		int i10 = i1 * i0;
		int i11 = 0;
		int i8 = i10 << 1;
		int i12 = i0 << 1;
		int i13 = i0 + i12;
		int i14 = 0;

		int i9;
		float f19;
		float f20;
		float f21;
		for(i9 = 0; i9 < i1; ++i9) {
			f19 = f2[i12 - 1] + f2[i12 - 1];
			f21 = f2[i14] + taur * f19;
			f3[i11] = f2[i14] + f19;
			f20 = taui * (f2[i12] + f2[i12]);
			f3[i11 + i10] = f21 - f20;
			f3[i11 + i8] = f21 + f20;
			i11 += i0;
			i12 += i13;
			i14 += i13;
		}

		if(i0 != 1) {
			i11 = 0;
			i12 = i0 << 1;

			for(i9 = 0; i9 < i1; ++i9) {
				int i15;
				i13 = i14 = (i15 = i11 + (i11 << 1)) + i12;
				int i16 = i11;
				int i17;
				int i18 = (i17 = i11 + i10) + i10;

				for(i8 = 2; i8 < i0; i8 += 2) {
					i14 += 2;
					i13 -= 2;
					i15 += 2;
					i16 += 2;
					i17 += 2;
					i18 += 2;
					f19 = f2[i14 - 1] + f2[i13 - 1];
					f21 = f2[i15 - 1] + taur * f19;
					f3[i16 - 1] = f2[i15 - 1] + f19;
					f20 = f2[i14] - f2[i13];
					f19 = f2[i15] + taur * f20;
					f3[i16] = f2[i15] + f20;
					float f22 = taui * (f2[i14 - 1] - f2[i13 - 1]);
					f20 = taui * (f2[i14] + f2[i13]);
					float f23 = f21 - f20;
					f21 += f20;
					f20 = f19 + f22;
					f19 -= f22;
					f3[i17 - 1] = f4[i5 + i8 - 2] * f23 - f4[i5 + i8 - 1] * f20;
					f3[i17] = f4[i5 + i8 - 2] * f20 + f4[i5 + i8 - 1] * f23;
					f3[i18 - 1] = f6[i7 + i8 - 2] * f21 - f6[i7 + i8 - 1] * f19;
					f3[i18] = f6[i7 + i8 - 2] * f19 + f6[i7 + i8 - 1] * f21;
				}

				i11 += i0;
			}

		}
	}

	static void dradb4(int i0, int i1, float[] f2, float[] f3, float[] f4, int i5, float[] f6, int i7, float[] f8, int i9) {
		int i12 = i1 * i0;
		int i13 = 0;
		int i14 = i0 << 2;
		int i15 = 0;
		int i18 = i0 << 1;

		int i11;
		int i16;
		int i17;
		float f24;
		float f25;
		float f26;
		float f27;
		for(i11 = 0; i11 < i1; ++i11) {
			i16 = i15 + i18;
			f25 = f2[i16 - 1] + f2[i16 - 1];
			f27 = f2[i16] + f2[i16];
			f26 = f2[i15] - f2[(i16 += i18) - 1];
			f24 = f2[i15] + f2[i16 - 1];
			f3[i13] = f24 + f25;
			f3[i17 = i13 + i12] = f26 - f27;
			f3[i17 += i12] = f24 - f25;
			f3[i17 + i12] = f26 + f27;
			i13 += i0;
			i15 += i14;
		}

		if(i0 >= 2) {
			float f20;
			float f21;
			if(i0 != 2) {
				i13 = 0;

				for(i11 = 0; i11 < i1; ++i11) {
					i17 = (i16 = i15 = (i14 = i13 << 2) + i18) + i18;
					int i19 = i13;

					for(int i10 = 2; i10 < i0; i10 += 2) {
						i14 += 2;
						i15 += 2;
						i16 -= 2;
						i17 -= 2;
						i19 += 2;
						f20 = f2[i14] + f2[i17];
						f21 = f2[i14] - f2[i17];
						float f22 = f2[i15] - f2[i16];
						f27 = f2[i15] + f2[i16];
						f26 = f2[i14 - 1] - f2[i17 - 1];
						f24 = f2[i14 - 1] + f2[i17 - 1];
						float f23 = f2[i15 - 1] - f2[i16 - 1];
						f25 = f2[i15 - 1] + f2[i16 - 1];
						f3[i19 - 1] = f24 + f25;
						f25 = f24 - f25;
						f3[i19] = f21 + f22;
						f22 = f21 - f22;
						f24 = f26 - f27;
						f26 += f27;
						f21 = f20 + f23;
						f23 = f20 - f23;
						int i28;
						f3[(i28 = i19 + i12) - 1] = f4[i5 + i10 - 2] * f24 - f4[i5 + i10 - 1] * f21;
						f3[i28] = f4[i5 + i10 - 2] * f21 + f4[i5 + i10 - 1] * f24;
						f3[(i28 += i12) - 1] = f6[i7 + i10 - 2] * f25 - f6[i7 + i10 - 1] * f22;
						f3[i28] = f6[i7 + i10 - 2] * f22 + f6[i7 + i10 - 1] * f25;
						f3[(i28 += i12) - 1] = f8[i9 + i10 - 2] * f26 - f8[i9 + i10 - 1] * f23;
						f3[i28] = f8[i9 + i10 - 2] * f23 + f8[i9 + i10 - 1] * f26;
					}

					i13 += i0;
				}

				if(i0 % 2 == 1) {
					return;
				}
			}

			i13 = i0;
			i14 = i0 << 2;
			i15 = i0 - 1;
			i16 = i0 + i18;

			for(i11 = 0; i11 < i1; ++i11) {
				f20 = f2[i13] + f2[i16];
				f21 = f2[i16] - f2[i13];
				f26 = f2[i13 - 1] - f2[i16 - 1];
				f24 = f2[i13 - 1] + f2[i16 - 1];
				f3[i15] = f24 + f24;
				f3[i17 = i15 + i12] = sqrt2 * (f26 - f20);
				f3[i17 += i12] = f21 + f21;
				f3[i17 + i12] = -sqrt2 * (f26 + f20);
				i15 += i0;
				i13 += i14;
				i16 += i14;
			}

		}
	}

	static void dradbg(int i0, int i1, int i2, int i3, float[] f4, float[] f5, float[] f6, float[] f7, float[] f8, float[] f9, int i10) {
		int i11 = 0;
		int i15 = 0;
		int i25 = 0;
		int i33 = 0;
		float f34 = 0.0F;
		float f35 = 0.0F;
		int i36 = 0;
		short s12 = 100;

		while(true) {
			int i13;
			int i14;
			int i16;
			int i17;
			int i18;
			int i19;
			int i20;
			int i21;
			int i22;
			int i23;
			int i24;
			int i26;
			int i27;
			int i37;
			int i39;
			switch(s12) {
			case 100:
				i25 = i1 * i0;
				i15 = i2 * i0;
				float f38;
				f34 = (float)Math.cos((double)(f38 = tpi / (float)i1));
				f35 = (float)Math.sin((double)f38);
				i33 = i0 - 1 >>> 1;
				i36 = i1;
				i11 = i1 + 1 >>> 1;
				if(i0 < i2) {
					s12 = 103;
					break;
				}

				i16 = 0;
				i17 = 0;

				for(i14 = 0; i14 < i2; ++i14) {
					i18 = i16;
					i19 = i17;

					for(i39 = 0; i39 < i0; ++i39) {
						f7[i18] = f4[i19];
						++i18;
						++i19;
					}

					i16 += i0;
					i17 += i25;
				}

				s12 = 106;
				break;
			case 103:
				i16 = 0;

				for(i39 = 0; i39 < i0; ++i39) {
					i17 = i16;
					i18 = i16;

					for(i14 = 0; i14 < i2; ++i14) {
						f7[i17] = f4[i18];
						i17 += i0;
						i18 += i25;
					}

					++i16;
				}
			case 106:
				i16 = 0;
				i17 = i36 * i15;
				i22 = i20 = i0 << 1;

				for(i13 = 1; i13 < i11; ++i13) {
					i16 += i15;
					i17 -= i15;
					i18 = i16;
					i19 = i17;
					i21 = i20;

					for(i14 = 0; i14 < i2; ++i14) {
						f7[i18] = f4[i21 - 1] + f4[i21 - 1];
						f7[i19] = f4[i21] + f4[i21];
						i18 += i0;
						i19 += i0;
						i21 += i25;
					}

					i20 += i22;
				}

				if(i0 == 1) {
					s12 = 116;
				} else {
					if(i33 < i2) {
						s12 = 112;
						break;
					}

					i16 = 0;
					i17 = i36 * i15;
					i22 = 0;

					for(i13 = 1; i13 < i11; ++i13) {
						i16 += i15;
						i17 -= i15;
						i18 = i16;
						i19 = i17;
						i23 = i22 += i0 << 1;

						for(i14 = 0; i14 < i2; ++i14) {
							i20 = i18;
							i21 = i19;
							i24 = i23;
							i26 = i23;

							for(i39 = 2; i39 < i0; i39 += 2) {
								i20 += 2;
								i21 += 2;
								i24 += 2;
								i26 -= 2;
								f7[i20 - 1] = f4[i24 - 1] + f4[i26 - 1];
								f7[i21 - 1] = f4[i24 - 1] - f4[i26 - 1];
								f7[i20] = f4[i24] - f4[i26];
								f7[i21] = f4[i24] + f4[i26];
							}

							i18 += i0;
							i19 += i0;
							i23 += i25;
						}
					}

					s12 = 116;
				}
				break;
			case 112:
				i16 = 0;
				i17 = i36 * i15;
				i22 = 0;

				for(i13 = 1; i13 < i11; ++i13) {
					i16 += i15;
					i17 -= i15;
					i18 = i16;
					i19 = i17;
					i23 = i22 += i0 << 1;
					i24 = i22;

					for(i39 = 2; i39 < i0; i39 += 2) {
						i18 += 2;
						i19 += 2;
						i23 += 2;
						i24 -= 2;
						i20 = i18;
						i21 = i19;
						i26 = i23;
						i27 = i24;

						for(i14 = 0; i14 < i2; ++i14) {
							f7[i20 - 1] = f4[i26 - 1] + f4[i27 - 1];
							f7[i21 - 1] = f4[i26 - 1] - f4[i27 - 1];
							f7[i20] = f4[i26] - f4[i27];
							f7[i21] = f4[i26] + f4[i27];
							i20 += i0;
							i21 += i0;
							i26 += i25;
							i27 += i25;
						}
					}
				}
			case 116:
				float f30 = 1.0F;
				float f28 = 0.0F;
				i16 = 0;
				i24 = i17 = i36 * i3;
				i18 = (i1 - 1) * i3;

				for(i39 = 1; i39 < i11; ++i39) {
					i16 += i3;
					i17 -= i3;
					float f40 = f34 * f30 - f35 * f28;
					f28 = f34 * f28 + f35 * f30;
					f30 = f40;
					i19 = i16;
					i20 = i17;
					i21 = 0;
					i22 = i3;
					i23 = i18;

					for(i14 = 0; i14 < i3; ++i14) {
						f6[i19++] = f8[i21++] + f30 * f8[i22++];
						f6[i20++] = f28 * f8[i23++];
					}

					float f42 = f30;
					float f32 = f28;
					float f31 = f30;
					float f29 = f28;
					i21 = i3;
					i22 = i24 - i3;

					for(i13 = 2; i13 < i11; ++i13) {
						i21 += i3;
						i22 -= i3;
						float f41 = f42 * f31 - f32 * f29;
						f29 = f42 * f29 + f32 * f31;
						f31 = f41;
						i19 = i16;
						i20 = i17;
						i26 = i21;
						i27 = i22;

						for(i14 = 0; i14 < i3; ++i14) {
							int i10001 = i19++;
							f6[i10001] += f31 * f8[i26++];
							i10001 = i20++;
							f6[i10001] += f29 * f8[i27++];
						}
					}
				}

				i16 = 0;

				for(i13 = 1; i13 < i11; ++i13) {
					i17 = i16 += i3;

					for(i14 = 0; i14 < i3; ++i14) {
						f8[i14] += f8[i17++];
					}
				}

				i16 = 0;
				i17 = i36 * i15;

				for(i13 = 1; i13 < i11; ++i13) {
					i16 += i15;
					i17 -= i15;
					i18 = i16;
					i19 = i17;

					for(i14 = 0; i14 < i2; ++i14) {
						f7[i18] = f5[i18] - f5[i19];
						f7[i19] = f5[i18] + f5[i19];
						i18 += i0;
						i19 += i0;
					}
				}

				if(i0 == 1) {
					s12 = 132;
				} else {
					if(i33 < i2) {
						s12 = 128;
						break;
					}

					i16 = 0;
					i17 = i36 * i15;

					for(i13 = 1; i13 < i11; ++i13) {
						i16 += i15;
						i17 -= i15;
						i18 = i16;
						i19 = i17;

						for(i14 = 0; i14 < i2; ++i14) {
							i20 = i18;
							i21 = i19;

							for(i39 = 2; i39 < i0; i39 += 2) {
								i20 += 2;
								i21 += 2;
								f7[i20 - 1] = f5[i20 - 1] - f5[i21];
								f7[i21 - 1] = f5[i20 - 1] + f5[i21];
								f7[i20] = f5[i20] + f5[i21 - 1];
								f7[i21] = f5[i20] - f5[i21 - 1];
							}

							i18 += i0;
							i19 += i0;
						}
					}

					s12 = 132;
				}
				break;
			case 128:
				i16 = 0;
				i17 = i36 * i15;

				for(i13 = 1; i13 < i11; ++i13) {
					i16 += i15;
					i17 -= i15;
					i18 = i16;
					i19 = i17;

					for(i39 = 2; i39 < i0; i39 += 2) {
						i18 += 2;
						i19 += 2;
						i20 = i18;
						i21 = i19;

						for(i14 = 0; i14 < i2; ++i14) {
							f7[i20 - 1] = f5[i20 - 1] - f5[i21];
							f7[i21 - 1] = f5[i20 - 1] + f5[i21];
							f7[i20] = f5[i20] + f5[i21 - 1];
							f7[i21] = f5[i20] - f5[i21 - 1];
							i20 += i0;
							i21 += i0;
						}
					}
				}
			case 132:
				if(i0 == 1) {
					return;
				}

				for(i14 = 0; i14 < i3; ++i14) {
					f6[i14] = f8[i14];
				}

				i16 = 0;

				for(i13 = 1; i13 < i1; ++i13) {
					i17 = i16 += i15;

					for(i14 = 0; i14 < i2; ++i14) {
						f5[i17] = f7[i17];
						i17 += i0;
					}
				}

				if(i33 <= i2) {
					i37 = -i0 - 1;
					i16 = 0;

					for(i13 = 1; i13 < i1; ++i13) {
						i37 += i0;
						i16 += i15;
						i3 = i37;
						i17 = i16;

						for(i39 = 2; i39 < i0; i39 += 2) {
							i17 += 2;
							i3 += 2;
							i18 = i17;

							for(i14 = 0; i14 < i2; ++i14) {
								f5[i18 - 1] = f9[i10 + i3 - 1] * f7[i18 - 1] - f9[i10 + i3] * f7[i18];
								f5[i18] = f9[i10 + i3 - 1] * f7[i18] + f9[i10 + i3] * f7[i18 - 1];
								i18 += i0;
							}
						}
					}

					return;
				}

				s12 = 139;
				break;
			case 139:
				i37 = -i0 - 1;
				i16 = 0;

				for(i13 = 1; i13 < i1; ++i13) {
					i37 += i0;
					i17 = i16 += i15;

					for(i14 = 0; i14 < i2; ++i14) {
						i3 = i37;
						i18 = i17;

						for(i39 = 2; i39 < i0; i39 += 2) {
							i3 += 2;
							i18 += 2;
							f5[i18 - 1] = f9[i10 + i3 - 1] * f7[i18 - 1] - f9[i10 + i3] * f7[i18];
							f5[i18] = f9[i10 + i3 - 1] * f7[i18] + f9[i10 + i3] * f7[i18 - 1];
						}

						i17 += i0;
					}
				}

				return;
			}
		}
	}

	static void drftb1(int i0, float[] f1, float[] f2, float[] f3, int i4, int[] i5) {
		int i8 = 0;
		int i11 = 0;
		int i15 = 0;
		int i16 = 0;
		int i10 = i5[1];
		int i9 = 0;
		int i7 = 1;
		int i12 = 1;

		for(int i6 = 0; i6 < i10; ++i6) {
			byte b13 = 100;

			label71:
			while(true) {
				int i18;
				switch(b13) {
				case 100:
					i8 = (i11 = i5[i6 + 2]) * i7;
					i16 = (i15 = i0 / i8) * i7;
					if(i11 != 4) {
						b13 = 103;
					} else {
						int i14 = (i18 = i12 + i15) + i15;
						if(i9 != 0) {
							dradb4(i15, i7, f2, f1, f3, i4 + i12 - 1, f3, i4 + i18 - 1, f3, i4 + i14 - 1);
						} else {
							dradb4(i15, i7, f1, f2, f3, i4 + i12 - 1, f3, i4 + i18 - 1, f3, i4 + i14 - 1);
						}

						i9 = 1 - i9;
						b13 = 115;
					}
					break;
				case 103:
					if(i11 != 2) {
						b13 = 106;
					} else {
						if(i9 != 0) {
							dradb2(i15, i7, f2, f1, f3, i4 + i12 - 1);
						} else {
							dradb2(i15, i7, f1, f2, f3, i4 + i12 - 1);
						}

						i9 = 1 - i9;
						b13 = 115;
					}
					break;
				case 106:
					if(i11 != 3) {
						b13 = 109;
					} else {
						i18 = i12 + i15;
						if(i9 != 0) {
							dradb3(i15, i7, f2, f1, f3, i4 + i12 - 1, f3, i4 + i18 - 1);
						} else {
							dradb3(i15, i7, f1, f2, f3, i4 + i12 - 1, f3, i4 + i18 - 1);
						}

						i9 = 1 - i9;
						b13 = 115;
					}
					break;
				case 109:
					if(i9 != 0) {
						dradbg(i15, i11, i7, i16, f2, f2, f2, f1, f1, f3, i4 + i12 - 1);
					} else {
						dradbg(i15, i11, i7, i16, f1, f1, f1, f2, f2, f3, i4 + i12 - 1);
					}

					if(i15 == 1) {
						i9 = 1 - i9;
					}
				case 115:
					break label71;
				}
			}

			i7 = i8;
			i12 += (i11 - 1) * i15;
		}

		if(i9 != 0) {
			for(int i17 = 0; i17 < i0; ++i17) {
				f1[i17] = f2[i17];
			}

		}
	}
}
