package com.jcraft.jorbis;

class Floor0$EchstateFloor0 {
	int[] codewords;
	float[] curve;
	long frameno;
	long codes;
	final Floor0 this$0;

	Floor0$EchstateFloor0(Floor0 floor01) {
		this.this$0 = floor01;
	}
}
