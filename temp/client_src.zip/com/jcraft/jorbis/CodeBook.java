package com.jcraft.jorbis;

import com.jcraft.jogg.Buffer;

class CodeBook {
	int dim;
	int entries;
	StaticCodeBook c = new StaticCodeBook();
	float[] valuelist;
	int[] codelist;
	CodeBook$DecodeAux decode_tree;
	private int[] t = new int[15];

	int encode(int i1, Buffer buffer2) {
		buffer2.write(this.codelist[i1], this.c.lengthlist[i1]);
		return this.c.lengthlist[i1];
	}

	int errorv(float[] f1) {
		int i2 = this.best(f1, 1);

		for(int i3 = 0; i3 < this.dim; ++i3) {
			f1[i3] = this.valuelist[i2 * this.dim + i3];
		}

		return i2;
	}

	int encodev(int i1, float[] f2, Buffer buffer3) {
		for(int i4 = 0; i4 < this.dim; ++i4) {
			f2[i4] = this.valuelist[i1 * this.dim + i4];
		}

		return this.encode(i1, buffer3);
	}

	int encodevs(float[] f1, Buffer buffer2, int i3, int i4) {
		int i5 = this.besterror(f1, i3, i4);
		return this.encode(i5, buffer2);
	}

	synchronized int decodevs_add(float[] f1, int i2, Buffer buffer3, int i4) {
		i4 /= this.dim;
		if(this.t.length < i4) {
			this.t = new int[i4];
		}

		int i5;
		int i6;
		for(i6 = 0; i6 < i4; ++i6) {
			if((i5 = this.decode(buffer3)) == -1) {
				return -1;
			}

			this.t[i6] = i5 * this.dim;
		}

		i6 = 0;

		for(i5 = 0; i6 < this.dim; i5 += i4) {
			for(int i7 = 0; i7 < i4; ++i7) {
				f1[i2 + i5 + i7] += this.valuelist[this.t[i7] + i6];
			}

			++i6;
		}

		return 0;
	}

	int decodev_add(float[] f1, int i2, Buffer buffer3, int i4) {
		int i10002;
		int i5;
		int i6;
		int i7;
		if(this.dim > 8) {
			i5 = 0;

			while(i5 < i4) {
				if((i6 = this.decode(buffer3)) == -1) {
					return -1;
				}

				i7 = i6 * this.dim;

				for(i6 = 0; i6 < this.dim; f1[i2 + i10002] += this.valuelist[i7 + i6++]) {
					i10002 = i5++;
				}
			}
		} else {
			i5 = 0;

			while(i5 < i4) {
				if((i6 = this.decode(buffer3)) == -1) {
					return -1;
				}

				i7 = i6 * this.dim;
				i6 = 0;
				switch(this.dim) {
				case 0:
				default:
					break;
				case 8:
					i10002 = i5++;
					int i10001 = i2 + i10002;
					float f8 = f1[i2 + i10002];
					++i6;
					f1[i10001] = f8 + this.valuelist[i7 + 0];
				case 7:
					i10002 = i5++;
					f1[i2 + i10002] += this.valuelist[i7 + i6++];
				case 6:
					i10002 = i5++;
					f1[i2 + i10002] += this.valuelist[i7 + i6++];
				case 5:
					i10002 = i5++;
					f1[i2 + i10002] += this.valuelist[i7 + i6++];
				case 4:
					i10002 = i5++;
					f1[i2 + i10002] += this.valuelist[i7 + i6++];
				case 3:
					i10002 = i5++;
					f1[i2 + i10002] += this.valuelist[i7 + i6++];
				case 2:
					i10002 = i5++;
					f1[i2 + i10002] += this.valuelist[i7 + i6++];
				case 1:
					i10002 = i5++;
					f1[i2 + i10002] += this.valuelist[i7 + i6];
				}
			}
		}

		return 0;
	}

	int decodev_set(float[] f1, int i2, Buffer buffer3, int i4) {
		int i5 = 0;

		while(i5 < i4) {
			int i6;
			if((i6 = this.decode(buffer3)) == -1) {
				return -1;
			}

			int i7 = i6 * this.dim;

			for(i6 = 0; i6 < this.dim; f1[i2 + i5++] = this.valuelist[i7 + i6++]) {
			}
		}

		return 0;
	}

	int decodevv_add(float[][] f1, int i2, int i3, Buffer buffer4, int i5) {
		int i8 = 0;
		int i6 = i2 / i3;

		while(i6 < (i2 + i5) / i3) {
			int i7;
			if((i7 = this.decode(buffer4)) == -1) {
				return -1;
			}

			int i9 = i7 * this.dim;

			for(i7 = 0; i7 < this.dim; ++i7) {
				int i10001 = i8++;
				f1[i10001][i6] += this.valuelist[i9 + i7];
				if(i8 == i3) {
					i8 = 0;
					++i6;
				}
			}
		}

		return 0;
	}

	int decode(Buffer buffer1) {
		int i2 = 0;
		CodeBook$DecodeAux codeBook$DecodeAux3 = this.decode_tree;
		int i4;
		if((i4 = buffer1.look(codeBook$DecodeAux3.tabn)) >= 0) {
			i2 = codeBook$DecodeAux3.tab[i4];
			buffer1.adv(codeBook$DecodeAux3.tabl[i4]);
			if(i2 <= 0) {
				return -i2;
			}
		}

		do {
			switch(buffer1.read1()) {
			case -1:
			default:
				return -1;
			case 0:
				i2 = codeBook$DecodeAux3.ptr0[i2];
				break;
			case 1:
				i2 = codeBook$DecodeAux3.ptr1[i2];
			}
		} while(i2 > 0);

		return -i2;
	}

	int decodevs(float[] f1, int i2, Buffer buffer3, int i4, int i5) {
		int i7;
		if((i7 = this.decode(buffer3)) == -1) {
			return -1;
		} else {
			int i6;
			switch(i5) {
			case -1:
				i5 = 0;

				for(i6 = 0; i5 < this.dim; i6 += i4) {
					f1[i2 + i6] = this.valuelist[i7 * this.dim + i5];
					++i5;
				}

				return i7;
			case 0:
				i5 = 0;

				for(i6 = 0; i5 < this.dim; i6 += i4) {
					f1[i2 + i6] += this.valuelist[i7 * this.dim + i5];
					++i5;
				}

				return i7;
			case 1:
				i5 = 0;

				for(i6 = 0; i5 < this.dim; i6 += i4) {
					f1[i2 + i6] *= this.valuelist[i7 * this.dim + i5];
					++i5;
				}
			}

			return i7;
		}
	}

	int best(float[] f1, int i2) {
		int i3 = -1;
		float f4 = 0.0F;
		int i5 = 0;

		for(int i6 = 0; i6 < this.entries; ++i6) {
			if(this.c.lengthlist[i6] > 0) {
				float f7 = dist(this.dim, this.valuelist, i5, f1, i2);
				if(i3 == -1 || f7 < f4) {
					f4 = f7;
					i3 = i6;
				}
			}

			i5 += this.dim;
		}

		return i3;
	}

	int besterror(float[] f1, int i2, int i3) {
		int i4 = this.best(f1, i2);
		int i5;
		switch(i3) {
		case 0:
			i3 = 0;

			for(i5 = 0; i3 < this.dim; i5 += i2) {
				f1[i5] -= this.valuelist[i4 * this.dim + i3];
				++i3;
			}

			return i4;
		case 1:
			i3 = 0;

			for(i5 = 0; i3 < this.dim; i5 += i2) {
				float f6;
				if((f6 = this.valuelist[i4 * this.dim + i3]) == 0.0F) {
					f1[i5] = 0.0F;
				} else {
					f1[i5] /= f6;
				}

				++i3;
			}
		}

		return i4;
	}

	void clear() {
	}

	private static float dist(int i0, float[] f1, int i2, float[] f3, int i4) {
		float f5 = 0.0F;

		for(int i6 = 0; i6 < i0; ++i6) {
			float f7 = f1[i2 + i6] - f3[i6 * i4];
			f5 += f7 * f7;
		}

		return f5;
	}

	int init_decode(StaticCodeBook staticCodeBook1) {
		this.c = staticCodeBook1;
		this.entries = staticCodeBook1.entries;
		this.dim = staticCodeBook1.dim;
		this.valuelist = staticCodeBook1.unquantize();
		this.decode_tree = this.make_decode_tree();
		if(this.decode_tree == null) {
			this.clear();
			return -1;
		} else {
			return 0;
		}
	}

	static int[] make_words(int[] i0, int i1) {
		int[] i2 = new int[33];
		int[] i3 = new int[i1];

		int i4;
		int i5;
		int i6;
		for(i4 = 0; i4 < i1; ++i4) {
			if((i5 = i0[i4]) > 0) {
				i6 = i2[i5];
				if(i5 < 32 && i6 >>> i5 != 0) {
					return null;
				}

				i3[i4] = i6;

				int i7;
				for(i7 = i5; i7 > 0; --i7) {
					if((i2[i7] & 1) != 0) {
						if(i7 == 1) {
							++i2[1];
						} else {
							i2[i7] = i2[i7 - 1] << 1;
						}
						break;
					}

					++i2[i7];
				}

				for(i7 = i5 + 1; i7 < 33 && i2[i7] >>> 1 == i6; ++i7) {
					i6 = i2[i7];
					i2[i7] = i2[i7 - 1] << 1;
				}
			}
		}

		for(i4 = 0; i4 < i1; ++i4) {
			i5 = 0;

			for(i6 = 0; i6 < i0[i4]; ++i6) {
				i5 = (i5 <<= 1) | i3[i4] >>> i6 & 1;
			}

			i3[i4] = i5;
		}

		return i3;
	}

	CodeBook$DecodeAux make_decode_tree() {
		int i1 = 0;
		CodeBook$DecodeAux codeBook$DecodeAux2;
		int[] i3 = (codeBook$DecodeAux2 = new CodeBook$DecodeAux(this)).ptr0 = new int[this.entries << 1];
		int[] i4 = codeBook$DecodeAux2.ptr1 = new int[this.entries << 1];
		int[] i5;
		if((i5 = make_words(this.c.lengthlist, this.c.entries)) == null) {
			return null;
		} else {
			codeBook$DecodeAux2.aux = this.entries << 1;

			int i6;
			int i7;
			int i8;
			for(i6 = 0; i6 < this.entries; ++i6) {
				if(this.c.lengthlist[i6] > 0) {
					i7 = 0;

					for(i8 = 0; i8 < this.c.lengthlist[i6] - 1; ++i8) {
						if((i5[i6] >>> i8 & 1) == 0) {
							if(i3[i7] == 0) {
								++i1;
								i3[i7] = i1;
							}

							i7 = i3[i7];
						} else {
							if(i4[i7] == 0) {
								++i1;
								i4[i7] = i1;
							}

							i7 = i4[i7];
						}
					}

					if((i5[i6] >>> i8 & 1) == 0) {
						i3[i7] = -i6;
					} else {
						i4[i7] = -i6;
					}
				}
			}

			codeBook$DecodeAux2.tabn = Util.ilog(this.entries) - 4;
			if(codeBook$DecodeAux2.tabn < 5) {
				codeBook$DecodeAux2.tabn = 5;
			}

			i6 = 1 << codeBook$DecodeAux2.tabn;
			codeBook$DecodeAux2.tab = new int[i6];
			codeBook$DecodeAux2.tabl = new int[i6];

			for(i7 = 0; i7 < i6; ++i7) {
				i8 = 0;

				int i9;
				for(i9 = 0; i9 < codeBook$DecodeAux2.tabn && (i8 > 0 || i9 == 0); ++i9) {
					if((i7 & 1 << i9) != 0) {
						i8 = i4[i8];
					} else {
						i8 = i3[i8];
					}
				}

				codeBook$DecodeAux2.tab[i7] = i8;
				codeBook$DecodeAux2.tabl[i7] = i9;
			}

			return codeBook$DecodeAux2;
		}
	}
}
