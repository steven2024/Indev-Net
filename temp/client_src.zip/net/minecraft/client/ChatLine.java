package net.minecraft.client;

public final class ChatLine {
	public int updateCounter;
}
