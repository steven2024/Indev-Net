package net.minecraft.game.level.generator.noise;

public abstract class NoiseGenerator {
	public abstract double generateNoise(double d1, double d3);
}
