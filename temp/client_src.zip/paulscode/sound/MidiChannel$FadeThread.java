package paulscode.sound;

class MidiChannel$FadeThread extends SimpleThread {
	final MidiChannel this$0;

	private MidiChannel$FadeThread(MidiChannel midiChannel1) {
		this.this$0 = midiChannel1;
	}

	public void run() {
		while(!this.dying()) {
			if(this.this$0.fadeOutGain == -1.0F && this.this$0.fadeInGain == 1.0F) {
				this.snooze(3600000L);
			}

			MidiChannel.access$100(this.this$0);
			this.snooze(50L);
		}

		this.cleanup();
	}

	MidiChannel$FadeThread(MidiChannel midiChannel1, MidiChannel$1 midiChannel$12) {
		this(midiChannel1);
	}
}
